<?php

$id = $_POST['id'];

include('connection.php');

$data= "DELETE FROM fare WHERE id='$id'";
$db->query($data);

header('Location:fare.php');

?>