<?php
	include('connection.php');
	if(isset($_POST['submit'])){
		$id = $_POST['id'];
		$bus=$_POST['mybus'];
		$route=$_POST['myroute'];
		$date=$_POST['mydate'];
		$time= $_POST['mytime'];
		$amount= $_POST['myamount'];
		$status= $_POST['type'];
		
		
		$data = "INSERT INTO availabilty(bus,route,date,time,amount,status) VALUES('$bus','$route','$date','$time','$amount','$status')";
		
		$result = $db->query($data);
		
		header('Location:availability_view.php');
		
}
	include('header.php');	
	include('nav.php')	
?>		
		
    	 <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
		 <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Add_Availability</h4>
			  
			 <form class="form-horizontal style-form" method="POST" action="">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Bus</label>
                  <div class="col-sm-10">
                    <input type="text" name='mybus' class="form-control"/>
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Route</label>
                  <div class="col-sm-10">
                    <input type="text" name='myroute'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Date</label>
                  <div class="col-sm-10">
                    <input type="date" name='mydate'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Time</label>
                  <div class="col-sm-10">
                    <input type="time" name='mytime'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Amount</label>
                  <div class="col-sm-10">
                    <input type="number" name='myamount' class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Status</label>
                  <div class="col-sm-10">
                    <select name='type' class="form-control">
						<option value="Abailable">Available</option>
						<option value="Not Abailable">Not Abailable</option>
					</select>
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <input type="submit" name="submit" value="Add_Availability" class="btn btn-theme"/>
                  </div>
                </div>
              </form>
	
<?php include('footer.php');?>	




 
	