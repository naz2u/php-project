<?php
		
	echo $email = $_POST['myemail'];	
	echo $password = $_POST['password'];	


?>	