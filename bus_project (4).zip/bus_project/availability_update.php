<?php
	
include('connection.php');

if(isset($_POST['submit'])){
		$id = $_POST['id'];
		$bus=$_POST['mybus'];
		$route=$_POST['myroute'];
		$date=$_POST['mydate'];
		$time= $_POST['mytime'];
		$amount= $_POST['myamount'];
		$status= $_POST['status'];
		
		
		$data ="UPDATE availabilty SET bus='$bus',route='$route',date='$date',
		time ='$time',amount='$amount', status='$status' WHERE id='$id'";
		
		$result = $db->query($data);
		
		header('Location:availability_view.php');
		
	}
		include('header.php');
		include('nav.php'); 
		
		$id = $_POST['id'];
		
		$data = "SELECT * FROM availabilty WHERE id ='$id'";
		$result = $db->query($data);
		
		while($row = $result->fetch_assoc()){
					
?>	
			 
			 <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
		 <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Availability_update</h4>
			  
			 <form class="form-horizontal style-form" method="POST" action="">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Bus</label>
                  <div class="col-sm-10">
                    <input type="text" value="<?php echo $row['bus'];?>" name='mybus'class="form-control"/>
					<input type="hidden" name="id" value="<?php echo $row['id'];?>" />
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Route</label>
                  <div class="col-sm-10">
                    <input type="text" value="<?php echo $row['route'];?>" name='myroute'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Date</label>
                  <div class="col-sm-10">
                    <input type="date" value="<?php echo $row['date'];?>" name='mydate'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Time</label>
                  <div class="col-sm-10">
                    <input type="time" value="<?php echo $row['time'];?>" name='mytime'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Amount</label>
                  <div class="col-sm-10">
                    <input type="number" value="<?php echo $row['amount'];?>" name='myamount'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Status</label>
                  <div class="col-sm-10">
                    <select name='status' class="form-control">
						<option value="Abailable">Available</option>
						<option value="Not Abailable">Not Abailable</option>
					</option>
					</select>
                  </div>
                </div>
				 
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <input type="submit" name="submit" value="Update" class="btn btn-theme"/>
                  </div>
                </div>
              </form>
	
<?php
}


?>
            </div>
          <!-- col-lg-12-->
        </div>
	</div>
   </section>
</section>
    <!--main content end-->
    <!--footer start-->
	
<?php include('footer.php');?>	


