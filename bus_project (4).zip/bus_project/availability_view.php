<?php include('header.php');?>	
<?php include('nav.php');?>	
   
<script>
$(document).ready(function(){
    $('#myTable1').DataTable();
});
</script>
 <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
	  
         <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
             <table id="myTable1" class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Availability</h4>
                <hr>
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Bus</th>
                    <th>Route</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Amount</th>
                    <th>Status</th>
					<th>Action</th>
                  </tr>
                </thead>
                <tbody border="1">
		<?php 	
			include('connection.php');
			
			$data ="SELECT * FROM availabilty";
			$result = $db->query($data);	
				
		while($row = $result->fetch_assoc()){	
				
?>
			 	
        <tr>
			<td><?php echo $row['id'];?></td>
			<td><?php					
					$data2= "SELECT * FROM bus_list WHERE id='".$row['bus']."'";
					$result2=$db->query($data2);
							
					while($row2 = $result2->fetch_assoc()){
						echo $row2['b_name'];
					}	
				?></td>
			<td><?php echo $row['route'];?></td>
			<td><?php echo $row['date'];?></td>
			<td><?php echo $row['time'];?></td>
			<td><?php					
					$data1= "SELECT * FROM booking WHERE id='".$row['amount']."'";
					$result1=$db->query($data1);
							
					while($row1 = $result1->fetch_assoc()){
						echo $row1['amount'];
					}	
				?></td>
			<td><?php echo $row['status'];?></td>
			
			<td class="action_btn">
				<form  action='availability_update.php' method='POST'>
					<input type="hidden" value='<?php echo $row['id'];?>' name='id'/>
					<button type="submit" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
				</form>
				
				<form Action='availability_delete.php' method='POST'>
					<input type="hidden" value='<?php echo $row['id'];?>' name='id'/>
					<button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
				</form>
			</td>
			
        </tr>
<?php	
		  
	}  
	
?>	
                </tbody>
              </table>
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>
		
        <!-- /row -->
      </section>
    </section>
    <!--main content end-->
    <!--footer start-->
	
<?php include('footer.php');?>	