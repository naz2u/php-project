<?php include('header.php');?>	
<?php include('nav.php');?>	
   

 <script>
$(document).ready(function(){
    $('#myTable1').DataTable();
});
</script>
    <section id="main-content">
      <section class="wrapper">
         <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table id="myTable1"  class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Add fare</h4>
                <hr>
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Fare</th>
                    <th>Route name</th>
                    <th>Time</th>
					<th>Action</th>
                    
                    
                  </tr>
                </thead>
                <tbody>
		<?php 	
			include('connection.php');
			
			$data ="SELECT * FROM route";
			$result = $db->query($data);	
				
		while($row = $result->fetch_assoc()){	
				
?>
			 	
        <tr>
			<td><?php echo $row['id'];?></td>
			<td><?php echo $row['fare'];?></td>
			<td><?php echo $row['route_name'];?></td>
			<td><?php echo $row['time'];?></td>
			
			
			<td class="action_btn">
				<form  action='route.php' method='POST'>
					<input type="hidden" value='<?php echo $row['id'];?>' name='id'/>
					<button type="submit" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
				</form>
				
				<form Action='route_delete.php' method='POST'>
					<input type="hidden" value='<?php echo $row['id'];?>' name='id'/>
					<button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
				</form>
			</td>
        </tr>
<?php	
		  
	}  
	
?>	
                </tbody>
              </table>
            </div>
     
          </div>
        
        </div>
		
       
      </section>
    </section>
  
	
<?php include('footer.php');?>	