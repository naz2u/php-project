<?php
	$id = $_POST['id'];
	
	include('connection.php');
	
	$data = "DELETE FROM customers WHERE id='$id'";
		
	 $db->query($data);
	
	header('Location:customers.php');
?>