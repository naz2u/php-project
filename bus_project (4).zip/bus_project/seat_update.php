<?php
include('connection.php');

if(isset($_POST['submit'])){
		$id = $_POST['id'];
		$name=$_POST['myname'];
		
		$data ="UPDATE seats SET name='$name' WHERE id='$id'";
		
		$result = $db->query($data);
		
		header('Location:seat.php');
		
	}
		include('header.php');
		include('nav.php'); 
		
		$id = $_POST['id'];
		
		$data = "SELECT * FROM seats WHERE id ='$id'";
		$result = $db->query($data);
		
		while($row = $result->fetch_assoc()){
					
?>	
			 
			 <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
		 <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Seat_update</h4>
			  
			 <form class="form-horizontal style-form" method="POST" action="">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Seat name</label>
                  <div class="col-sm-10">
                    <input type="text" value="<?php echo $row['name'];?>" name='myname' class="form-control"/>
					<input type="hidden" name="id" value="<?php echo $row['id'];?>" />
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <input type="submit" name="submit" value="Update Seat" class="btn btn-theme"/>
                  </div>
                </div>
              </form>
			  
<?php
}

?>
            </div>
          <!-- col-lg-12-->
        </div>
	</div>
   </section>
</section>
    <!--main content end-->
    <!--footer start-->
<?php include('footer.php');?>	
