<?php include('header.php');?>	
<?php include('nav.php');?>	
	
    <!--main content start-->
	
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
			<a href='add_user.php'><button style='background:#ff9980'>add new register</button></a>
        </div>
	
		
		
        <!-- /row -->
      </section>
    </section>
    <!--main content end-->
    <!--footer start-->
	
	
<?php include('footer.php');?>	