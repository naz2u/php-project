<?php
	$id = $_POST['id'];
	
	include('connection.php');
	
	$data = "DELETE FROM booking WHERE id='$id'";
		
	 $db->query($data);
	
	header('Location:booking_view.php');
?>