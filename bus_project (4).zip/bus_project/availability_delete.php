<?php
	$id = $_POST['id'];
	
	include('connection.php');
	
	$data = "DELETE FROM availabilty WHERE id='$id'";
		
	 $db->query($data);
	
	header('Location:availability_view.php');
?>