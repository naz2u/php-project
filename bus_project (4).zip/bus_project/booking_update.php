<?php
	
	include('connection.php');
	if(isset($_POST['submit'])){
		$id = $_POST['id'];
		$p_name=$_POST['p_name'];
		$mobile=$_POST['mymobile'];
		$seat=$_POST['myseat'];
		$bus= $_POST['mybus'];
		$counter= $_POST['mycounter'];
		$route= $_POST['myroute'];
		$date= $_POST['mydate'];
		$time= $_POST['mytime'];
		$luggage= $_POST['myluggage'];
		$amount= $_POST['myamount'];
		$booked= $_POST['mybooked_date'];
		
		$db = new mysqli("localhost", "root", "", "busbooking");
		
		$data ="UPDATE booking SET passenger_name='$p_name', mobile='$mobile', seat='$seat', bus ='$bus', counter='$counter', route='$route', date='$date', time='$time', luggage='$luggage', amount='$amount', date_booked='$booked' WHERE id='$id'";
		
		$result = $db->query($data);
		
		header('Location:booking_view.php');	
	}
		include('header.php');
		include('nav.php');

	
		$id = $_POST['id'];
		
		$data = "SELECT * FROM booking WHERE id ='$id'";
		$result = $db->query($data);
		
		while($row = $result->fetch_assoc()){
					
?>	
<script type="text/javascript" language="javascript">

$(document).ready(function(){

	$("#second").click(function(){
		$(".first").toggle(300);
	});	

var seats = $("#second").val();
var values = seats.split(',');

$(".first input" ).each(function( index ) {
	var val = jQuery( this ).val();         
	if (values.includes(val)) {
		$(this).prop('checked', true);
	}    
});  
  


$(".first input").on("change", function() 
{
  var $this = $(this);
  
  if ($this.is(":checked")) 
  {
    values.push($this.val());
  }
  else 
  {
    values = values.filter(x => x != $this.val());
  }
  
  $("#second").val(values);
});




});
</script>		 
		 
		  
		 
			 <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
		 <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Booking_update</h4>
			  
			 <form class="form-horizontal style-form" method="POST" action="#">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Pass_name</label>
                  <div class="col-sm-10">
                    <input type="text" value="<?php echo $row['passenger_name'];?>" name='p_name'class="form-control"/>
					<input type="hidden" name="id" value="<?php echo $row['id'];?>" />
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Mobile</label>
                  <div class="col-sm-10">
                    <input type="number" value="<?php echo $row['mobile'];?>" name='mymobile'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Seat</label>
                  <div class="col-sm-10">
                    <input type="number"  name='myseat'class="form-control">
					
					<input type="text" value="<?php echo $row['seat'];?>" id="second" name='myseat' class="form-control"/>
					
						<div  class="first" style="border:1px solid gray; width:120px;">
							<table>
								<tr>
									<td colspan="4"></td>
									<td align="right"> <div id="driver"></div> </td>
								</tr>
								<tr>
									<td><input type="checkbox" value="A1"/><span>A1</span></td>
									<td><input type="checkbox" value="A2"/><span>A2</span></td>
									<td class="walk"> A </td>
									<td><input type="checkbox" value="A3"/><span>A3</span></td>
									<td><input type="checkbox" value="A4"/><span>A4</span></td>
								</tr>
								<tr>
									<td><input type="checkbox" value="B1"/><span>B1</span></td>
									<td><input type="checkbox" value="B2"/><span>B2</span></td>
									<td class="walk"> B </td>
									<td><input type="checkbox" value="B3"/><span>B3</span></td>
									<td><input type="checkbox" value="B4"/><span>B4</span></td>
								</tr>
								<tr>
									<td><input type="checkbox" value="C1"/><span>C1</span></td>
									<td><input type="checkbox" value="C2"/><span>C2</span></td>
									<td class="walk"> C </td>
									<td><input type="checkbox" value="C3"/><span>C3</span></td>
									<td><input type="checkbox" value="C4"/><span>C4</span></td
								</tr>
								<tr>
									<td><input type="checkbox" value="D1"/><span>D1</span></td>
									<td><input type="checkbox" value="D2"/><span>D2</span></td>
									<td class="walk"> D </td>
									<td><input type="checkbox" value="D3"/><span>D3</span></td>
									<td><input type="checkbox" value="D4"/><span>B4</span></td
								</tr>
								<tr>
									<td><input type="checkbox" value="E1"/><span>E1</span></td>
									<td><input type="checkbox" value="E2"/><span>E2</span></td>
									<td class="walk"> E </td>
									<td><input type="checkbox" value="E3"/><span>E3</span></td>
									<td><input type="checkbox" value="E4"/><span>E4</span></td
								</tr>
								<tr>
									<td><input type="checkbox" value="F1"/><span>F1</span></td>
									<td><input type="checkbox" value="F2"/><span>F2</span></td>
									<td class="walk"> F </td>
									<td><input type="checkbox" value="F3"/><span>F3</span></td>
									<td><input type="checkbox" value="F4"/><span>F4</span></td
								</tr>
								<tr>
									<td><input type="checkbox" value="G1"/><span>G1</span></td>
									<td><input type="checkbox" value="G2"/><span>G2</span></td>
									<td class="walk"> G </td>
									<td><input type="checkbox" value="G3"/><span>G3</span></td>
									<td><input type="checkbox" value="G4"/><span>G4</span></td
								</tr>
								<tr>
									<td><input type="checkbox" value="H1"/><span>H1</span></td>
									<td><input type="checkbox" value="H2"/><span>H2</span></td>
									<td class="walk"> H </td>
									<td><input type="checkbox" value="H3"/><span>H3</span></td>
									<td><input type="checkbox" value="H4"/><span>H4</span></td
								</tr>
								<tr>
									<td><input type="checkbox" value="I1"/><span>I1</span></td>
									<td><input type="checkbox" value="I2"/><span>I2</span></td>
									<td class="walk"> I </td>
									<td><input type="checkbox" value="I3"/><span>I3</span></td>
									<td><input type="checkbox" value="I4"/><span>I4</span></td
								</tr>
							</table>
						</div>					
					
					
					
					
					
					
					
					
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Bus</label>
                  <div class="col-sm-10">
                    <input type="text" value="<?php echo $row['bus'];?>" name='mybus'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Counter</label>
                  <div class="col-sm-10">
                    <input type="text" value="<?php echo $row['counter'];?>" name='mycounter'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Route</label>
                  <div class="col-sm-10">
                    <input type='text' value="<?php echo $row['route'];?>" name='myroute' class="form-control"></select>
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Date</label>
                  <div class="col-sm-10">
                    <input type="date" value="<?php echo $row['date'];?>" name='mydate'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Time</label>
                  <div class="col-sm-10">
                    <input type="time" value="<?php echo $row['time'];?>" name='mytime'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Luggage</label>
                  <div class="col-sm-10">
                    <input type="number" value="<?php echo $row['luggage'];?>" name='myluggage'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Amount</label>
                  <div class="col-sm-10">
                    <input type="number" value="<?php echo $row['amount'];?>" name='myamount'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Date_Booked</label>
                  <div class="col-sm-10">
                    <input type="date" value="<?php echo $row['date_booked'];?>" name='mybooked_date'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <input type="submit" name="submit" value="Update" class="btn btn-theme"/>
                  </div>
                </div>
              </form>
	
<?php
}


?>
            </div>
          <!-- col-lg-12-->
        </div>
	</div>
   </section>
</section>
    <!--main content end-->
    <!--footer start-->
	
<?php include('footer.php');?>	


