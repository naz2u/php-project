-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2020 at 09:06 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `busbooking`
--

-- --------------------------------------------------------

--
-- Table structure for table `availabilty`
--

CREATE TABLE `availabilty` (
  `id` int(10) UNSIGNED NOT NULL,
  `bus` int(10) UNSIGNED NOT NULL,
  `route` int(10) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `amount` varchar(10) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `availabilty`
--

INSERT INTO `availabilty` (`id`, `bus`, `route`, `date`, `time`, `amount`, `status`) VALUES
(1, 1, 2, '2019-12-04', '09:11:11', '1', 'available'),
(2, 2, 3, '2019-12-02', '02:27:10', '2', 'available'),
(3, 3, 2, '2019-12-03', '02:17:06', '1', 'not available'),
(4, 2, 3, '2019-12-31', '00:59:00', '1', 'availble'),
(6, 2, 4, '2019-12-23', '02:03:00', '2', 'not available'),
(7, 2, 4, '2019-12-24', '00:01:00', '1', 'Not Abailable'),
(8, 2, 3, '2019-12-25', '04:04:00', '1', 'Abailable'),
(9, 2, 3, '2019-12-24', '01:02:00', '1', 'Not Abailable'),
(10, 0, 0, '2020-01-31', '01:01:00', '1', 'Not Abailable');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(10) UNSIGNED NOT NULL,
  `passenger_name` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `seat` varchar(50) NOT NULL,
  `bus` int(11) NOT NULL,
  `counter` int(11) NOT NULL,
  `route` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `luggage` varchar(30) NOT NULL,
  `amount` double(20,2) NOT NULL,
  `date_booked` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `passenger_name`, `mobile`, `seat`, `bus`, `counter`, `route`, `date`, `time`, `luggage`, `amount`, `date_booked`) VALUES
(1, 'afzal hasan', '01743327440', 'A2,A1', 2, 1, 2, '2019-12-03', '00:00:00', '2', 1.00, '2019-12-02'),
(2, 'salam hossain', '01710974964', 'B3,B4', 2, 2, 1, '2019-12-13', '00:00:00', '1', 2.00, '2019-12-10'),
(4, 'Md Ismail Hossain', '4587697', 'E4', 3, 3, 3, '0000-00-00', '02:01:00', '3', 1.00, '2019-12-23'),
(5, 'Md Ismail Hossain', '0185465893', ',E3', 2, 2, 4, '2020-01-22', '01:02:00', '2', 3.00, '2020-01-21'),
(6, 'Md Ismail Hossain', '776', ',G1,G2', 2, 2, 3, '2020-01-08', '13:54:00', '2', 2.00, '2020-01-09'),
(7, 'Saimum Hasan', '01743327440', ',G3,G4', 3, 4, 2, '2020-01-31', '04:04:00', '1', 4.00, '2020-01-24'),
(8, 'Md Ismail Hossain', '56855', 'A2,H2', 3, 1, 1, '0000-00-00', '00:00:00', '1', 1.00, '2020-01-10'),
(9, 'imran', '014586752', 'C3,C4', 2, 1, 1, '2020-01-16', '02:03:00', '1', 4.00, '2020-01-24');

-- --------------------------------------------------------

--
-- Table structure for table `bus_list`
--

CREATE TABLE `bus_list` (
  `id` int(10) UNSIGNED NOT NULL,
  `b_name` varchar(50) NOT NULL,
  `seat_capacity` varchar(50) NOT NULL,
  `bus_name_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bus_list`
--

INSERT INTO `bus_list` (`id`, `b_name`, `seat_capacity`, `bus_name_id`) VALUES
(1, 'shayamoli1', '42', 1),
(2, 'shayamoli2', '36', 4),
(3, 'Hanif green', '42', 3);

-- --------------------------------------------------------

--
-- Table structure for table `bus_type`
--

CREATE TABLE `bus_type` (
  `id` int(10) UNSIGNED NOT NULL,
  `bus_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bus_type`
--

INSERT INTO `bus_type` (`id`, `bus_name`) VALUES
(1, 'hino ac'),
(3, 'marcities'),
(4, 'bolvo ac'),
(5, 'bolvo none ac');

-- --------------------------------------------------------

--
-- Table structure for table `counter`
--

CREATE TABLE `counter` (
  `id` int(10) UNSIGNED NOT NULL,
  `counter_name` varchar(50) NOT NULL,
  `counter_mobile` varchar(50) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `counter`
--

INSERT INTO `counter` (`id`, `counter_name`, `counter_mobile`, `address`) VALUES
(1, 'saiful bus counter', '0174327440', 'pabna bypuss mor,pabna.'),
(2, 'iqbal bus counter', '0147895642', 'ataikula bazar,nearby new square building,ataikula.'),
(3, 'bakshipara azim bus counter', '0145896563', 'bakshipara jute ,inside of technical college,pabna'),
(4, 'dharmagram nizam bus counter', '124563987', 'dharmagram,pabna.');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(40) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `id_number` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `fullname`, `phone`, `id_number`) VALUES
(1, 'kamrul hasan', '0712345678', '4410109291020'),
(2, 'Kelvin Kevoh', '0792323200', '33767192'),
(4, 'maxim company', '01710974964', '458692632');

-- --------------------------------------------------------

--
-- Table structure for table `fare`
--

CREATE TABLE `fare` (
  `id` int(10) UNSIGNED NOT NULL,
  `bus_type_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fare`
--

INSERT INTO `fare` (`id`, `bus_type_id`, `route_id`, `price`) VALUES
(1, 1, 2, 500.00);

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE `route` (
  `id` int(10) UNSIGNED NOT NULL,
  `fare` varchar(50) NOT NULL,
  `route_name` text NOT NULL,
  `time` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`id`, `fare`, `route_name`, `time`) VALUES
(1, '400', 'dhaka-pabna.', '11:12'),
(2, '800', 'pabna-chittagram', '12:30'),
(3, '350', 'dhaka-nabinagor', '12:30'),
(4, '300', 'dhaka-tangail', '');

-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE `seats` (
  `id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seats`
--

INSERT INTO `seats` (`id`, `name`) VALUES
(1, 'A1'),
(2, 'A2'),
(3, 'B1'),
(4, 'B2'),
(5, 'C1'),
(6, 'C2'),
(7, 'D1'),
(8, 'D2'),
(9, 'E1'),
(10, 'E2'),
(11, 'F1'),
(12, 'F2'),
(13, 'z1');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(32) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(25) NOT NULL,
  `user_type_id` int(30) NOT NULL,
  `photo` varchar(10) DEFAULT 'profil.php'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `mobile`, `email`, `password`, `user_type_id`, `photo`) VALUES
(2, 'Md Ismail Hossain', '01710974964', 'ismailhossain123@gmail.com', '123456', 2, 'ui-sam.jpg'),
(3, 'Kiron Ahmed', '01303355191', 'lvr1lipi@gmail.com', '123456', 3, 'ui-zac.jpg'),
(5, 'Md Karim Hossain', '012458695', 'nazmulhaqueedu@gmail.com', '123456', 3, 'fr-02.jpg'),
(6, 'Md Nazmul Hasan', '28548664', 'nazmulhaqueedu@gmail.com', '123456', 2, 'fr-03.jpg'),
(8, 'Shamim ', '012346879', 'nazmulhaqueedu@gmail.com', '123456', 1, 'nazmul.jpg'),
(9, 'Muhsin Guru', '01743327440', 'nazmul12@gmail.com', '', 2, 'ui-danro.j'),
(10, 'nazmul', '045585544', 'nazmul12@gmail.com', '', 2, 'fr-03.jpg'),
(11, 'nazmul', '25544585', 'nazmulhaq@gmail.com', '', 3, 'ui-sam.jpg'),
(12, 'Nazmul Hasan', '017458654455', 'nazmulhaqueedu01743@gmail2.com', '', 2, 'fr-03.jpg'),
(13, 'Shafiqul Islam', '01745689', 'nazmul12@gmail.com', '', 1, 'nazmul.jpg'),
(14, 'Mst Sonia Khatun', '014789563241', 'soniakhatun@gmail.com', '123456', 2, 'fr-02.jpg'),
(15, 'nazmul', '01457856', 'nazmul12@gmail.com', '7c4a8d09ca3762af61e595209', 2, 'fr-01.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user_type`
--

CREATE TABLE `user_type` (
  `id` int(32) UNSIGNED NOT NULL,
  `rank` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_type`
--

INSERT INTO `user_type` (`id`, `rank`) VALUES
(1, 'admin'),
(2, 'editor'),
(3, 'saler');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `availabilty`
--
ALTER TABLE `availabilty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bus_list`
--
ALTER TABLE `bus_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bus_type`
--
ALTER TABLE `bus_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `counter`
--
ALTER TABLE `counter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fare`
--
ALTER TABLE `fare`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seats`
--
ALTER TABLE `seats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_type`
--
ALTER TABLE `user_type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `availabilty`
--
ALTER TABLE `availabilty`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `bus_list`
--
ALTER TABLE `bus_list`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bus_type`
--
ALTER TABLE `bus_type`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `counter`
--
ALTER TABLE `counter`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `fare`
--
ALTER TABLE `fare`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `route`
--
ALTER TABLE `route`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seats`
--
ALTER TABLE `seats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(32) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user_type`
--
ALTER TABLE `user_type`
  MODIFY `id` int(32) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
