<?php include('header.php');?>	
<?php include('nav.php');?>	
   
   
<?php
	include('connection.php');

	if(isset($_POST['submit'])){
		
		$counter_name = $_POST['mycounter_name'];
		$counter_mobile = $_POST['counter_mobile'];
		$address = $_POST['address'];
	

		
		$data= "INSERT INTO  counter(counter_name,counter_mobile,address) VALUES('$counter_name','$counter_mobile','$address')";
		$result=$db->query($data);
		
		header('Location:counter.php');
	}
?>   
   

    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
	  
		<div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Add New Counter</h4>

			  <form class="form-horizontal style-form" method="POST" action="#" enctype="multipart/form-data" >
			  
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Counter_name</label>
                  <div class="col-sm-10">
                    <input type="text" name='mycounter_name' class="form-control" />
                  </div>
                </div>	
				
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Counter_mobile</label>
                  <div class="col-sm-10">
                    <input type="text" name='counter_mobile' class="form-control" />
                  </div>
                </div>   

				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Address</label>
                  <div class="col-sm-10">
                    <input type="text" name='address' class="form-control" />
                  </div>
                </div>		
             

				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">				 
					<input type="submit" name="submit" value="Add Counter" class="btn btn-primary" />
                  </div>
                </div>
	
              </form>
			  
            </div>
          </div>
          <!-- col-lg-12-->
        </div>
	  
      </section>
    </section>
    <!--main content end-->
    <!--footer start-->
	
<?php include('footer.php');?>	