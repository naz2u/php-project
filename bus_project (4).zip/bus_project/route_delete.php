<?php

$db = new mysqli("localhost", "root", "", "bus_resurvation");

	$id = $_POST['id'];
	
	include('connection.php');
	
	
	$data = "DELETE FROM route WHERE id='$id'";
		
	 $db->query($data);
	
	header('Location:route.php');
?>