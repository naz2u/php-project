
<?php
	if(isset($_POST['submit'])){
		$search=$_POST['name'];
		
		$sb = new mysqli("localhost","root","","busbooking");
		
		$data = "SELECT * FROM booking WHERE MATCH(passenger_name) AGAINST('$search')";
		$result = $sb->query($data);
		

	while($row = $result->fetch_assoc()){
		echo"<p>".$row['mobile']."_".$row['date']."</p>";
			
	}
}else{echo'
		<form action="" method="POST">
			<p>Name:<input type="text" name="name"/></p>
			<p><input type="submit" name="submit" value="send"/></p>
		</form>';
}
	
?>




