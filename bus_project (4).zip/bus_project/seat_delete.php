<?php
	$id = $_POST['id'];
	
	include('connection.php');
	
	$data = "DELETE FROM seats WHERE id='$id'";
		
	 $db->query($data);
	
	header('Location:seat.php');
?>