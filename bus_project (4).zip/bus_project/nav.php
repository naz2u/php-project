 <aside>
       <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="index.php">
			
			  <?php
		  
			if(isset($_SESSION['photo'])){
				echo '<img src="img/uploads/'.$_SESSION['photo'].'" class="img-circle" width="80">
				  </a></p>
                  <h5 class="centered">'.$_SESSION['name'].'</h5>
				
				
				';
			}else{
				echo '<img src="img/ismail1.jpeg" class="img-circle" width="80">
				  </a></p>
                   <h5 class="centered">profile</h5>
				
				';
			}
		  ?>
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
              </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-users"></i>
              <span>USERS</span>
              </a>
            <ul class="sub">
              <li><a href="user.php">All Users</a></li>
              <li><a href="add_user.php">Add User</a></li>
            </ul>
          </li>
		  
		  <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-check-circle"></i>
              <span>AVAILABILITIES</span>
              </a>
            <ul class="sub">
              <li><a href="availability_view.php">All Availability</a></li>
              <li><a href="add_availability.php">Add Availability</a></li>
            </ul>
          </li>
		  
		   <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-money"></i>
              <span>BOOKING</span>
              </a>
            <ul class="sub">
              <li><a href="booking_view.php">All Booking</a></li>
              <li><a href="add_booking.php">Add Booking</a></li>
            </ul>
          </li>
		  
		   <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-user"></i>
              <span>CUSTOMARS</span>
              </a>
            <ul class="sub">
              <li><a href="customers.php">All Customars</a></li>
              <li><a href="customer_add.php">Add Customars</a></li>
            </ul>
          </li>
		  
		   <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-university"></i>
              <span>COUNTER</span>
              </a>
            <ul class="sub">
              <li><a href="counter.php">All Counter</a></li>
              <li><a href="add_counter.php">Add Counter</a></li>
            </ul>
          </li>
		  
		   <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-subway"></i>
              <span>BUS TYPE</span>
              </a>
            <ul class="sub">
              <li><a href="bus_type.php">All Bus Type</a></li>
              <li><a href="add_bus_type.php">Add Buses Type</a></li>
            </ul>
          </li>
		  
		  <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-bus"></i>
              <span>BUSES</span>
              </a>
            <ul class="sub">
              <li><a href="buses_view.php">All Bus</a></li>
              <li><a href="buses_add.php">Add Buses</a></li>
            </ul>
          </li>
		  
		  <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-sitemap"></i>
              <span>SEATS</span>
              </a>
            <ul class="sub">
              <li><a href="seat.php">All Seat</a></li>
              <li><a href="seat_add.php">Add Seat</a></li>
			  <li><a href="new.php">seatmanu</a></li>
            </ul>
          </li>
		  
		  <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-money"></i>
              <span>FARE</span>
              </a>
            <ul class="sub">
              <li><a href="fare.php">All Fare</a></li>
              <li><a href="add_fare.php">Add Fare</a></li>
            </ul>
          </li>
		  
		  <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-road"></i>
              <span>ROUTE</span>
              </a>
            <ul class="sub">
              <li><a href="route.php">All Route</a></li>
              <li><a href="add_route.php">Add Route</a></li>
            </ul>
          </li>
		  
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>