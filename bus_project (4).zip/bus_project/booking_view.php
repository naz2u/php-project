<?php include('header.php');?>	
<?php include('nav.php');?>	

<script>
$(document).ready(function(){
    $('#myTable1').DataTable();
});
</script>	


	
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
         <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
                <h4><i class="fa fa-angle-right"></i>Booking</h4>
				
                <hr>
              <table  id="myTable1" class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>P.Name</th>
                    <th>Mobile</th>
                    <th>Seat</th>
                    <th>Bus</th>
                    <th>C.Name</th>
                    <th>Route</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Luggage</th>
                    <th>Amount</th>
                    <th>Date Booked</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
				
		<?php 	
			include('connection.php');
			
			$data ="SELECT * FROM booking";
			$result = $db->query($data);	
				
		while($row = $result->fetch_assoc()){	
				
?>
			 	
        <tr>
			<td><?php echo $row['id'];?></td>
			<td><?php echo $row['passenger_name'];?></td>
			<td><?php echo $row['mobile'];?></td>
			<td><?php echo $row['seat'];?></td>
			<td>
				<?php					
						$data3= "SELECT * FROM bus_list WHERE id='".$row['bus']."'";
						$result3=$db->query($data3);	
						while($row3 = $result3->fetch_assoc()){
							echo $row3['b_name'];
						}	
				?></td>
				
			<td>
				<?php					
						$data1= "SELECT * FROM counter WHERE id='".$row['counter']."'";
						$result1=$db->query($data1);	
						while($row1 = $result1->fetch_assoc()){
							echo $row1['counter_name'];
						}	
				?>
			</td>
			
			<td>
				<?php					
					$data2= "SELECT * FROM route WHERE id='".$row['route']."'";
					$result2=$db->query($data2);	
					while($row2 = $result2->fetch_assoc()){
						echo $row2['route_name'];
					}	
				?>
			</td>
			
			<td><?php echo $row['date'];?></td>
			<td><?php echo $row['time'];?></td>
			<td><?php echo $row['luggage'];?></td>
			
			<td>
				<?php					
					$data4= "SELECT * FROM route WHERE id='".$row['amount']."'";
					$result4=$db->query($data4);
							
					while($row4 = $result4->fetch_assoc()){
						echo $row4['fare'];
					}	
				?>
			</td>
			<td><?php echo $row['date_booked'];?></td>
			
			<td class="action_btn">
				<form  action='booking_update.php' method='POST'>
					<input type="hidden" value='<?php echo $row['id'];?>' name='id'/>
					<button type="submit" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
				</form>
				
				<form Action='booking_delete.php' method='POST'>
					<input type="hidden" value='<?php echo $row['id'];?>' name='id'/>
					<button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
				</form>
			</td>
			
        </tr>
<?php	
		  
	}  
	
?>	
                </tbody>
              </table>
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>
		
        <!-- /row -->
      </section>
    </section>
    <!--main content end-->
    <!--footer start-->
	
<?php include('footer.php');?>
	