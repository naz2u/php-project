<?php include('header.php');?>	
<?php include('nav.php');?>	
   
   
<?php
	include('connection.php');

	if(isset($_POST['submit'])){
		
		$bus_name = $_POST['bus_name'];
		
	

		
		$data= "INSERT INTO  bus_type(bus_name) VALUES('$bus_name')";
		$result=$db->query($data);
		
		header('Location:bus_type.php');
	}
?>   
   

    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
	  
		<div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Add New Bus</h4>

			  <form class="form-horizontal style-form" method="POST" action="#" enctype="multipart/form-data" >
			  
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Bus_name</label>
                  <div class="col-sm-10">
                    <input type="text" name='bus_name' class="form-control" />
                  </div>
                </div>	
				
                
					
             

				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">				 
					<input type="submit" name="submit" value="Add Bus" class="btn btn-primary" />
                  </div>
                </div>
	
              </form>
			  
            </div>
          </div>
          <!-- col-lg-12-->
        </div>
	  
      </section>
    </section>
    <!--main content end-->
    <!--footer start-->
	
<?php include('footer.php');?>	