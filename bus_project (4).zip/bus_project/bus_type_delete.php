<?php

$id = $_POST['id'];

include('connection.php');

$data= "DELETE FROM bus_type WHERE id='$id'";
$db->query($data);

header('Location:bus_type.php');

?>