<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
    <style>
        .seat {
            height: 20px;
            width: 20px;
            border: 1px solid gray;
           cursor:pointer;
           background-color:white;
        }
        .walk{
            padding-right:8px;
            padding-left:8px;
			
        }
        #driver {
            background-color:gray;          
            height: 20px;
            border-radius: 50%;
        }
		
		.field{
			height:200px;
			width:150px;
		}
		.pp{
				height:15px;
				width:15px;
		}
    </style>

   

</head>
<body>

    <div style="border:1px solid gray; width:135px;">
        <table>
            <tr>
                <td colspan="4"></td>
                <td align="right"> <div id="driver"></div> </td>
            </tr>
            <tr>
                <td><div class="seat">A1</div> </td>
                <td><div class="seat">A2</div></td>
                <td class="walk"> A </td>
                <td><div class="seat">A3</div></td>
                <td><div class="seat">A4</div></td>
            </tr>
            <tr>
                <td><div class="seat">B1</div> </td>
                <td><div class="seat">B2</div></td>
                <td class="walk"> B </td>
                <td><div class="seat">B3</div></td>
                <td><div class="seat">B4</div></td>
            </tr>
            <tr>
                <td><div class="seat">C1</div> </td>
                <td><div class="seat">C2</div></td>
                <td class="walk"> C </td>
                <td><div class="seat">C3</div></td>
                <td><div class="seat">C4</div></td>
            </tr>
            <tr>
                <td><div class="seat">D1</div> </td>
                <td><div class="seat">D2</div></td>
                <td class="walk"> D </td>
                <td><div class="seat">D3</div></td>
                <td><div class="seat">D4</div></td>
            </tr>
            <tr>
                <td><div class="seat">E1</div> </td>
                <td><div class="seat">E2</div></td>
                <td class="walk"> E </td>
                <td><div class="seat">E3</div></td>
                <td><div class="seat">E4</div></td>
            </tr>
            <tr>
                <td><div class="seat">F1</div> </td>
                <td><div class="seat">F2</div></td>
                <td class="walk"> F </td>
                <td><div class="seat">F3</div></td>
                <td><div class="seat">F4</div></td>
            </tr>
            <tr>
                <td><div class="seat">G1</div> </td>
                <td><div class="seat">G2</div></td>
                <td class="walk"> G </td>
                <td><div class="seat">G3</div></td>
                <td><div class="seat">G4</div></td>
            </tr>
            <tr>
                <td><div class="seat">H1</div> </td>
                <td><div class="seat">H2</div></td>
                <td class="walk"> H </td>
                <td><div class="seat">H3</div></td>
                <td><div class="seat">H4</div></td>
            </tr>
            <tr>
                <td><div class="seat">I1</div> </td>
                <td><div class="seat">I2</div></td>
                <td class="walk"> I </td>
                <td><div class="seat">I3</div></td>
                <td><div class="seat">I4</div></td>
            </tr>
        </table>
    </div>
	
    <script>

        allSeats = document.querySelectorAll('.seat');
        for (var i = 0; i < allSeats.length; i++) {
            var seat = allSeats[i];
            seat.addEventListener('click', function () {
                var bgclr = this.style.backgroundColor;
                if(bgclr =='red')
                    this.style.backgroundColor = 'white'
                else
                    this.style.backgroundColor = 'green'
                debugger
            }, false);
        }

    </script>
</body>
</html>