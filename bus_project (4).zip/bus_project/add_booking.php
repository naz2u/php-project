
<script type="text/javascript" src="jquery-3.4.1.js"></script>
<script type="text/javascript" language="javascript">

$(document).ready(function(){

	$("#second").click(function(){
		$(".first").toggle(300);
	});	



var values = [];

$(".first input").on("change", function() 
{
  var $this = $(this);
  
  if ($this.is(":checked")) 
  {
    values.push($this.val());
  }
  else 
  {
    values = values.filter(x => x != $this.val());
  }
  
  $("#second").val(values);
});




});
</script>
<?php
	include('connection.php');
	if(isset($_POST['submit'])){
		$p_name=$_POST['p_name'];
		$mobile1=$_POST['mymobile1'];
		$seat1=$_POST['myseat1'];
		$bus1= $_POST['mybus1'];
		$counter1= $_POST['mycounter1'];
		$route1= $_POST['myroute1'];
		$date1= $_POST['mydate1'];
		$time1= $_POST['mytime1'];
		$luggage1= $_POST['myluggage1'];
		$amount1= $_POST['myamount1'];
		$booked1= $_POST['mybooked_date1'];
		
		$db = new mysqli("localhost", "root", "", "busbooking");
		$data = "INSERT INTO booking(passenger_name,mobile,seat,bus,counter,
		route,date,time,luggage,amount,date_booked) VALUES('$p_name','$mobile1','$seat1','$bus1','$counter1','$route1','$date1','$time1','$luggage1','$amount1','$booked1')";
		
		$result = $db->query($data);
		
		header('Location:booking_view.php');
}
		include('header.php');
		include('nav.php');
  
?>	
		


    	 <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
		 <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Add Booking</h4>
			  
			 <form class="form-horizontal style-form" method="POST" action="#">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Pass_name</label>
                  <div class="col-sm-10">
                    <input type="text" name='p_name' class="form-control"/>
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Mobile</label>
                  <div class="col-sm-10">
                    <input type="number" name='mymobile1'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Seat</label>
                  <div class="col-sm-10">
				  
                    <input type="text" placeholder="click" id="second" name='myseat1' class="form-control"/>
						<div  class="first" style="border:1px solid gray; width:120px;">
							<table>
								<tr>
									<td colspan="4"></td>
									<td align="right"> <div id="driver"></div> </td>
								</tr>
								<tr>
									<td><input type="checkbox" value="A1"/><span>A1</span></td>
									<td><input type="checkbox" value="A2"/><span>A2</span></td>
									<td class="walk"> A </td>
									<td><input type="checkbox" value="A3"/><span>A3</span></td>
									<td><input type="checkbox" value="A4"/><span>A4</span></td>
								</tr>
								<tr>
									<td><input type="checkbox" value="B1"/><span>B1</span></td>
									<td><input type="checkbox" value="B2"/><span>B2</span></td>
									<td class="walk"> B </td>
									<td><input type="checkbox" value="B3"/><span>B3</span></td>
									<td><input type="checkbox" value="B4"/><span>B4</span></td>
								</tr>
								<tr>
									<td><input type="checkbox" value="C1"/><span>C1</span></td>
									<td><input type="checkbox" value="C2"/><span>C2</span></td>
									<td class="walk"> C </td>
									<td><input type="checkbox" value="C3"/><span>C3</span></td>
									<td><input type="checkbox" value="C4"/><span>C4</span></td
								</tr>
								<tr>
									<td><input type="checkbox" value="D1"/><span>D1</span></td>
									<td><input type="checkbox" value="D2"/><span>D2</span></td>
									<td class="walk"> D </td>
									<td><input type="checkbox" value="D3"/><span>D3</span></td>
									<td><input type="checkbox" value="D4"/><span>B4</span></td
								</tr>
								<tr>
									<td><input type="checkbox" value="E1"/><span>E1</span></td>
									<td><input type="checkbox" value="E2"/><span>E2</span></td>
									<td class="walk"> E </td>
									<td><input type="checkbox" value="E3"/><span>E3</span></td>
									<td><input type="checkbox" value="E4"/><span>E4</span></td
								</tr>
								<tr>
									<td><input type="checkbox" value="F1"/><span>F1</span></td>
									<td><input type="checkbox" value="F2"/><span>F2</span></td>
									<td class="walk"> F </td>
									<td><input type="checkbox" value="F3"/><span>F3</span></td>
									<td><input type="checkbox" value="F4"/><span>F4</span></td
								</tr>
								<tr>
									<td><input type="checkbox" value="G1"/><span>G1</span></td>
									<td><input type="checkbox" value="G2"/><span>G2</span></td>
									<td class="walk"> G </td>
									<td><input type="checkbox" value="G3"/><span>G3</span></td>
									<td><input type="checkbox" value="G4"/><span>G4</span></td
								</tr>
								<tr>
									<td><input type="checkbox" value="H1"/><span>H1</span></td>
									<td><input type="checkbox" value="H2"/><span>H2</span></td>
									<td class="walk"> H </td>
									<td><input type="checkbox" value="H3"/><span>H3</span></td>
									<td><input type="checkbox" value="H4"/><span>H4</span></td
								</tr>
								<tr>
									<td><input type="checkbox" value="I1"/><span>I1</span></td>
									<td><input type="checkbox" value="I2"/><span>I2</span></td>
									<td class="walk"> I </td>
									<td><input type="checkbox" value="I3"/><span>I3</span></td>
									<td><input type="checkbox" value="I4"/><span>I4</span></td
								</tr>
							</table>
						</div>
						
						
						
						
						
						<script>

							allSeats = document.querySelectorAll('.seat');
							for (var i = 0; i < allSeats.length; i++) {
								var seat = allSeats[i];
								seat.addEventListener('click', function () {
									var bgclr = this.style.backgroundColor;
									if(bgclr =='red')
										this.style.backgroundColor = 'white'
									else
										this.style.backgroundColor = 'green'
									debugger
								}, false);
							}

						</script>
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Bus</label>
                  <div class="col-sm-10">
                    <select name='mybus1' class="form-control">
						<option value="1">shayamoli1</option>
						<option value="2">shayamoli</option>
						<option value="3">Hanif green</option>
					</select>
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Counter Name</label>
                  <div class="col-sm-10">
                    <select name='mycounter1' class="form-control">
						<option value="1">saiful bus counter</option>
						<option value="2">iqbal bus counter</option>
						<option value="3">bakshipara azim bus counter</option>
						<option value="4">dharmagram nizam bus counter</option>
					</select>
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Route</label>
                  <div class="col-sm-10">
                   <select name='myroute1' class="form-control">
						<option value="1">dhaka-pabna.</option>
						<option value="2">pabna-chittagram</option>
						<option value="3">dhaka-nabinagor</option>
						<option value="4">dhaka-tangail</option>
					</select>
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Date</label>
                  <div class="col-sm-10">
                    <input type='date' name="mydate1" class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Time</label>
                  <div class="col-sm-10">
                    <input type='time' name="mytime1" class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Luggage</label>
                  <div class="col-sm-10">
                    <input type='number' name="myluggage1" class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Amount</label>
                  <div class="col-sm-10">
                    <input type='number' name="myamount1" class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Date Booked</label>
                  <div class="col-sm-10">
                    <input type='date' name="mybooked_date1" class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <input type="submit" name="submit" value="Add_Booking" class="btn btn-theme"/>
                  </div>
                </div>
              </form>
			  </div>
          <!-- col-lg-12-->
        </div>
	</div>
   </section>
</section>

	
<?php include('footer.php');?>	




 
	