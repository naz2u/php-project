<?php
	$db = new mysqli("localhost", "root", "", "busbooking");
	
	if($db->connect_errno) {
		printf("Unable to connect to the database:<br /> %s",
		$db->connect_error);
		exit();
	}
?>