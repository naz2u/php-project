<?php 

	$id = $_POST['id'];
	

		$db= new mysqli('localhost','root','','bangladesh');
		$data="SELECT * FROM sub_district WHERE district_id='$id'";
		
		$result = $db->query($data);
		while($row = $result->fetch_assoc()){
			
			echo"<option value='{$row['id']}'>{$row['name']}</option>";
			
}
?>
	
