<?php include('header.php');?>	
<?php include('nav.php');?>	
   

 <script>
$(document).ready(function(){
    $('#myTable1').DataTable();
});
</script>
    <section id="main-content">
      <section class="wrapper">
         <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table id="myTable1"  class="table table-striped table-advance table-hover">
                <h4><i class="fa fa-angle-right"></i> Add fare</h4>
                <hr>
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>bus_type_id</th>
                    <th>route_id</th>
                    <th>price</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
		<?php 	
			include('connection.php');
			
			$data ="SELECT * FROM fare";
			$result = $db->query($data);	
				
		while($row = $result->fetch_assoc()){	
				
?>
			 	
        <tr>
			<td><?php echo $row['id'];?></td>
			<td><?php					
					$data3= "SELECT * FROM bus_type WHERE id='".$row['bus_type_id']."'";
					$result3=$db->query($data3);
							
					while($row3 = $result3->fetch_assoc()){
						echo $row3['bus_name'];
					}	
				?></td>
				
			<td><?php					
					$data2= "SELECT * FROM route WHERE id='".$row['route_id']."'";
					$result2=$db->query($data2);
							
					while($row2 = $result2->fetch_assoc()){
						echo $row2['route_name'];
					}	
				?></td>
			<td><?php echo $row['price'];?></td>
			
			
			<td class="action_btn">
				<form  action='fare_update.php' method='POST'>
					<input type="hidden" value='<?php echo $row['id'];?>' name='id'/>
					<button type="submit" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
				</form>
				
				<form Action='fare_delete.php' method='POST'>
					<input type="hidden" value='<?php echo $row['id'];?>' name='id'/>
					<button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
				</form>
			</td>
        </tr>
<?php	
		  
	}  
	
?>	
                </tbody>
              </table>
            </div>
     
          </div>
        
        </div>
		
       
      </section>
    </section>
  
	
<?php include('footer.php');?>	