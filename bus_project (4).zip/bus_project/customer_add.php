<?php
	include('connection.php');
	if(isset($_POST['submit'])){
		$id = $_POST['id'];
		$name=$_POST['myname'];
		$phone=$_POST['myphone'];
		$nid_number=$_POST['mynid'];
		
		$data = "INSERT INTO customers(fullname,phone,id_number) VALUES('$name','$phone','$nid_number')";
		
		$result = $db->query($data);
		
		header('Location:customers.php');
		
}
	include('header.php');	
	include('nav.php')	
?>		
		
    	 <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
		 <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Add_Customers</h4>
			  
			 <form class="form-horizontal style-form" method="POST" action="">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Full Name</label>
                  <div class="col-sm-10">
                    <input type="text" name='myname' class="form-control"/>
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Phone</label>
                  <div class="col-sm-10">
                    <input type="number" name='myphone' class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Nid Number</label>
                  <div class="col-sm-10">
                    <input type="number" name='mynid' class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <input type="submit" name="submit" value="Add_Customer" class="btn btn-theme"/>
                  </div>
                </div>
              </form>
	
<?php include('footer.php');?>	




 
	