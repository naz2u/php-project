<?php
	include('connection.php');
	if(isset($_POST['submit'])){
		$id = $_POST['id'];
		$busname=$_POST['bname'];
		$seat=$_POST['myseat'];
		$busid=$_POST['mybusid'];
		
		$data = "INSERT INTO bus_list(b_name,seat_capacity,bus_name_id) VALUES('$busname','$seat','$busid')";
		
		$result = $db->query($data);
		
		header('Location:buses_view.php');
		
}
	include('header.php');	
	include('nav.php')	
?>		
		
    	 <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
		 <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Add_Buses</h4>
			  
			 <form class="form-horizontal style-form" method="POST" action="">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Bus name</label>
                  <div class="col-sm-10">
                    <input type="text" name='bname' class="form-control"/>
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Seat capacity</label>
                  <div class="col-sm-10">
                    <input type="number" name='myseat' class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Bus name id</label>
                  <div class="col-sm-10">
                    <input type="number" name='mybusid' class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <input type="submit" name="submit" value="Add_Buses" class="btn btn-theme"/>
                  </div>
                </div>
              </form>
	
<?php include('footer.php');?>	




 
	