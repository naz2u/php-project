<?php
	$id = $_POST['id'];
	
	include('connection.php');
	
	$data = "DELETE FROM bus_list WHERE id='$id'";
		
	 $db->query($data);
	
	header('Location:buses_view.php');
?>