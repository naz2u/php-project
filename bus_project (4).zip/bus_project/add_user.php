  
<?php
	
	if(isset($_POST['submit'])){
		$id = $_POST['id'];
		$name=$_POST['myname'];
		$mobile=$_POST['mymobile'];
		$email=$_POST['myemail'];
		$password=hash('sha1',$_POST['mypassword']);
		$type_id = $_POST['type'];
		$photo = $_POST['photo'];
		
		
		$target_dir = "img/uploads/";
		$photo = $_FILES["photo"]["name"];
		$target_file = $target_dir/*.time()*/.basename($_FILES["photo"]["name"]);
		
		move_uploaded_file($_FILES["photo"]["tmp_name"],$target_file);
		
		echo "The file uploaded successfully";
	
		include('connection.php');
	
		$data = "INSERT INTO user(name,mobile,email,password,user_type_id,photo) VALUES('$name','$mobile','$email','$password','$type_id ','$photo')";
		
		$result = $db->query($data);
		
		header('Location:user.php');
}
	include('header.php');	
	include('nav.php');	
?>				
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
		 <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Add New User</h4>
             
			 <form class="form-horizontal style-form" method="POST" action="" enctype="multipart/form-data">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Name</label>
                  <div class="col-sm-10">
                    <input type="text" name='myname'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Mobile</label>
                  <div class="col-sm-10">
                    <input type="number" name='mymobile'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Email</label>
                  <div class="col-sm-10">
                    <input type="email" name='myemail'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Password</label>
                  <div class="col-sm-10">
                    <input type="password" name='mypassword'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">User Type</label>
                  <div class="col-sm-10">
                    <select name='type' class="form-control">
						<option value="1">admin</option>
						<option value="2">editor</option>
						<option value="3">saler</option>
					</select>
                  </div>
                </div>
				
		<div class="form-group">
            <label class="col-sm-2 col-sm-2 control-label">Photo</label>
				<div class="controls col-md-10">
					<div class="fileupload fileupload-new" data-provides="fileupload">
						<span class="btn btn-theme02 btn-file">
							<input type="file" name="photo" class="default" />
						</span>
					</div>
			</div>
        </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <input type="submit" name="submit" value="add user" class="btn btn-theme"/>
                  </div>
                </div>
              </form>
            </div>
          <!-- col-lg-12-->
        </div>
	</div>
   </section>
</section>
    <!--main content end-->
    <!--footer start-->
	
<?php include('footer.php');?>	




 
	