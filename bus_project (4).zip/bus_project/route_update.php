<?php include('header.php');?>	
<?php include('nav.php');
include('connection.php');  
?>	

			 
<?php
	
$db = new mysqli("localhost", "root", "", "bus_resurvation");

if(isset($_POST['submit'])){
		$id = $_POST['id'];
		$fare=$_POST['fare'];
		$to=$_POST['to'];
		$from=$_POST['from'];
		$time=$_POST['time'];
		
		
		
		if($_FILES["photo"]["tmp_name"]){
			$target_dir = "img/uploads/";
			$photo = $_FILES["photo"]["name"];
			$target_file = $target_dir.basename($_FILES["photo"]["name"]);
		
			move_uploaded_file($_FILES["photo"]["tmp_name"],$target_file);
		}else{
			$photo = $_POST['old_photo'];
		}
		
		
		
		
		
		$data ="UPDATE user SET id='$id',fare='$fare',to='$to',
		,from='$from' ,time='$time' WHERE id='$id'";
		
		$result = $db->query($data);
		
		header('Location:route.php');
		
	}


		
		
		
		
		
		$id = $_POST['id'];
		
		$data = "SELECT * FROM route WHERE id ='$id'";
		$result = $db->query($data);
		
		while($row = $result->fetch_assoc()){
			
			
?>	
			 
			 <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
		 <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Add New User</h4>
			  
			 <form class="form-horizontal style-form" method="POST" action="" enctype="multipart/form-data">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Id</label>
                  <div class="col-sm-10">
                    <input type="text" value="<?php echo $row['id'];?>" name='myname'class="form-control"/>
					<input type="hidden" name="id" value="<?php echo $row['id'];?>" />
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">fare</label>
                  <div class="col-sm-10">
                    <input type="number" value="<?php echo $row['fare'];?>" name='mymobile'class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">to</label>
                  <div class="col-sm-10">
                    <input type="email" value="<?php echo $row['to'];?>" name='myemail'class="form-control">
                  </div>
                </div>
				
				
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">from</label>
                  <div class="col-sm-10">
                    <input type="email" value="<?php echo $row['from'];?>" name='myemail'class="form-control">
                  </div>
                </div>
				
				
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">time</label>
                  <div class="col-sm-10">
                    <input type="email" value="<?php echo $row['time'];?>" name='myemail'class="form-control">
                  </div>
                </div>
				
				
				
				
				
				
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">User Type</label>
                  <div class="col-sm-10">
                    <select name='type'class="form-control">
					<option value="1">admin</option>
					<option value="2">editor</option>
					<option value="3">saler</option>
					</select>
                  </div>
                </div>
				
		<div class="form-group">
            <label class="col-sm-2 col-sm-2 control-label">Photo</label>
				<div class="controls col-md-10">
					<div class="fileupload fileupload-new" data-provides="fileupload">
						<span class="btn btn-theme02 btn-file">
							<input type="file" name="photo" class="default" />
							<input type="hidden" name="old_photo" value="<?php echo $row['photo'];?>" />
						</span>
					</div>
			</div>
        </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <input type="submit" name="submit" value="Update User" class="btn btn-theme"/>
                  </div>
                </div>
              </form>
	
<?php
}


?>
            </div>
          <!-- col-lg-12-->
        </div>
	</div>
   </section>
</section>
    <!--main content end-->
    <!--footer start-->
	
<?php include('footer.php');?>	


