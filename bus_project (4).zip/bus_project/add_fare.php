<?php include('header.php');?>	
<?php include('nav.php');?>	
   
   
<?php
	include('connection.php');

	if(isset($_POST['submit'])){
		
		$bus_type_id = $_POST['bus'];
		$route_id = $_POST['route'];
		$price = $_POST['price'];
	

		
		$data= "INSERT INTO  fare(bus_type_id,route_id,price) VALUES('$bus_type_id','$route_id','$price')";
		$result=$db->query($data);
		
		header('Location:fare.php');
	}
?>   
   

    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
	  
		<div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Add New Fare</h4>

			  <form class="form-horizontal style-form" method="POST" action="#" enctype="multipart/form-data" >
			  
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Bus_type_id</label>
                  <div class="col-sm-10">
                    <input type="text" name='bus' class="form-control" />
                  </div>
                </div>	
				
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Route_id</label>
                  <div class="col-sm-10">
                    <input type="text" name='route' class="form-control" />
                  </div>
                </div>   

				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Price</label>
                  <div class="col-sm-10">
                    <input type="text" name='price' class="form-control" />
                  </div>
                </div>		
             

				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">				 
					<input type="submit" name="submit" value="Add Counter" class="btn btn-primary" />
                  </div>
                </div>
	
              </form>
			  
            </div>
          </div>
          <!-- col-lg-12-->
        </div>
	  
      </section>
    </section>
    <!--main content end-->
    <!--footer start-->
	
<?php include('footer.php');?>	