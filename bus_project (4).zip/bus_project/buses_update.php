<?php
include('connection.php');

if(isset($_POST['submit'])){
		$id = $_POST['id'];
		$busname=$_POST['bname'];
		$seat=$_POST['myseat'];
		$busid=$_POST['mybusid'];
		
		$data ="UPDATE bus_list SET b_name='$busname', seat_capacity='$seat', bus_name_id='$busid'
		 WHERE id='$id'";
		
		$result = $db->query($data);
		
		header('Location:buses_view.php');
		
	}
		include('header.php');
		include('nav.php'); 
		
		$id = $_POST['id'];
		
		$data = "SELECT * FROM bus_list WHERE id ='$id'";
		$result = $db->query($data);
		
		while($row = $result->fetch_assoc()){
					
?>	
			 
			 <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
		 <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Buses_update</h4>
			  
			 <form class="form-horizontal style-form" method="POST" action="">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Bus name</label>
                  <div class="col-sm-10">
                    <input type="text" value="<?php echo $row['b_name'];?>" name='bname' class="form-control"/>
					<input type="hidden" name="id" value="<?php echo $row['id'];?>" />
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Seat capacity</label>
                  <div class="col-sm-10">
                    <input type="number" value="<?php echo $row['seat_capacity'];?>" name='myseat' class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Bus name id</label>
                  <div class="col-sm-10">
                    <input type="number" value="<?php echo $row['bus_name_id'];?>" name='mybusid' class="form-control">
                  </div>
                </div>
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <input type="submit" name="submit" value="Update Buses" class="btn btn-theme"/>
                  </div>
                </div>
              </form>
			  
<?php
}

?>
            </div>
          <!-- col-lg-12-->
        </div>
	</div>
   </section>
</section>
    <!--main content end-->
    <!--footer start-->
<?php include('footer.php');?>	
