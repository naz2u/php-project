<?php include('header.php');?>	
<?php include('nav.php');?>	
   
<script>
$(document).ready(function(){
    $('#myTable1').DataTable();
});
</script>

    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
	  
		<div class="row mt">
		  <div class="col-md-12">
			<div class="content-panel">
			  <table id="myTable1" class="table table-striped table-advance table-hover">
				<h4><i class="fa fa-angle-right"></i> All Bus</h4>
				<hr>
				<thead>
				  <tr>
					<th>ID</th>
					<th>Bus_name</th>
					<th>Action</th>
				  </tr>
				</thead>
				<tbody>
				
<?php

	include('connection.php');
	
	$data= "SELECT * FROM bus_type";
	$result=$db->query($data);

	while($row = $result->fetch_assoc()){
?>				
				  <tr>
					<td><?php echo $row['id'];?></td>
					<td><?php echo $row['bus_name'];?></td>
					
					
					<td class="action_btn">					
						<form action='bus_type_update.php' method='POST'>
							<input type='hidden' value='<?php echo $row['id'];?>' name='id' />
							<button type="submit" class="btn btn-primary btn-xs">
							  <i class="fa fa-pencil"></i>
							</button>
						</form>
						
						<form action='bus_type_delete.php' method='POST'>
							<input type='hidden' value='<?php echo $row['id'];?>' name='id' />
							<button type="submit" class="btn btn-danger btn-xs">
							  <i class="fa fa-trash-o"></i>
							</button>
						</form>
					</td>
				  </tr>
				  
				  
<?php
	}
?>				  
				  
				  
				</tbody>
			  </table>
			</div>
			<!-- /content-panel -->
		  </div>
		  <!-- /col-md-12 -->
		</div>	  
	  
      </section>
    </section>
    <!--main content end-->
    <!--footer start-->
	
<?php include('footer.php');?>	