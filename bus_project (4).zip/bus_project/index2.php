<html>
<head>
	<title> jquery evidence</title>
	<script src="jquery-3.4.1.js"></script>
</head>

<body>

	<script>
			$(document).ready(function(){
				
				$('#district').change(function(){
					var district_id = $('#district').val();
					$.post(
						'result.php',
						{id :district_id},
						function(data){
							$('.content-panel').html(data);
						}
					);
					
				});
			});
	</script>	
	<div class="wrapper">
		<form>
			<select id="district">	
				<option >select</option>
	
<?php 
	
		$db= new mysqli('localhost','root','','busbooking');
		$data="SELECT * FROM booking";
		$result=$db->query($data);
		while($row =$result->fetch_assoc()){
			
			echo"<option value='{$row['id']}'>{$row['name']}</option>";
			
}
	?>
				
			</select>
			
			<select id="upazila">
				<option >select</option>
			</select>
		</form>
	
	</div>
</body>

</html>