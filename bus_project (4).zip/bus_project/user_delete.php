<?php
	$id = $_POST['id'];
	
	include('connection.php');
	
	
	$data = "DELETE FROM user WHERE id='$id'";
		
	 $db->query($data);
	
	header('Location:user.php');
?>