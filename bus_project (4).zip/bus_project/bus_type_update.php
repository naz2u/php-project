<?php include('header.php');?>	
<?php include('nav.php');?>	
   
   
<?php

	include('connection.php');

	if(isset($_POST['submit'])){	
		$id = $_POST['id'];
		$bus_name = $_POST['bus_name '];
		


		$data= "UPDATE bus_type SET bus_name ='$bus_name' WHERE id='$id' ";
		$result=$db->query($data);
		
		header('Location:bus_type.php');
	}
		
?>   
   

    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
	  
		<div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Update New Bus</h4>

<?php
$id = $_POST['id'];	
$data= "SELECT * FROM bus_type WHERE id=$id";
$result=$db->query($data);

while($row = $result->fetch_assoc()){	
?>

			  <form class="form-horizontal style-form" method="POST" action="#" enctype="multipart/form-data" >
			  
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Bus_name </label>
                  <div class="col-sm-10">
                    <input type="text" value="<?php echo $row['bus_name '];?>"  name='bus_name ' class="form-control" />
					<input type="hidden"  name='id' value="<?php echo $id; ?>"  />
                  </div>
                </div>	
				
               
				
           
				
				<div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label"></label>
                  <div class="col-sm-10">				 
					<input type="submit" name="submit" value="Update Bus" class="btn btn-primary" />
                  </div>
                </div>
	
              </form>
<?php } ?>			  
			  
			  
			  
            </div>
          </div>
          <!-- col-lg-12-->
        </div>
	  
      </section>
    </section>
    <!--main content end-->
    <!--footer start-->
	
<?php include('footer.php');?>	